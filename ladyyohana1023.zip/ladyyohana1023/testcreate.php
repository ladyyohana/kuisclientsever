<?php
include_once(__DIR__."/lib/Employees.php");
include_once(__DIR__."/lib/DataFormat.php");

header("Access-Control-Allow-Origin:*");
$employees = new Employees();
$employees->setValue('1717051023','Keyla Fara','Danisha','keylafara@gmail.com','081539448871','19990302','452','500000','02','786','08');
//echo $datakendaraan->nopol;
$result=$employees->create();
//$result=$employees->delete();

 
$format= new DataFormat();
// print_r($result);
echo $format->asJSON($result);

// $data=$employees->getAll();