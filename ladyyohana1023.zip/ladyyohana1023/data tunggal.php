<?php
header('Content-type: application/xml');
header("Access-Control-Allow-Origin:*");

echo "<data_kendaraan>";

	$host="localhost";
    $user="root";
    $passwd="";
    $namadb="layanan_pajak";
    $koneksi = mysqli_connect($host, $user, $passwd)or die (mysqli_error($koneksi));
    if ($koneksi)
    {
        mysqli_select_db($koneksi,$namadb) or die(mysql_error());
    }
	
$sql="select * from data_kendaraan where nopol='BE 2345 NF'";
$query=mysqli_query($koneksi, $sql) or die(mysqli_error($koneksi));
while ($infoDataKendaraan=mysqli_fetch_array($query)) {
	echo "<data_kendaraan>";
	echo "<nopol>".$infoDataKendaraan['nopol']."</nopol>";
	echo "<jenis_kendaraan>".$infoDataKendaraan['jenis_kendaraan']."</jenis_kendaraan>";
	echo "<asal_kota>".$infoDataKendaraan['asal_kota']."</asal_kota>";
	echo "</data_kendaraan>";
}
echo "</data_kendaraan>";